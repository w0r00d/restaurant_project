<div>
    

<div class="myForm sf">
<table>
    <tr>
<td>
<h3> Search for Restaurant </h3>
</td>
    </tr>
<tr>
<td> <input type="text" wire:model="search_term" placeholder="search for restaurant"/>
</td>
<td>
<button class="sb" wire:click ="search"> Search </button> </td>
</tr>
<tr>
    <th> Name </th> <th> Type</th>  <th> address</th> <th> Phone </th>
    </tr>
<!-- __BLOCK__ --><?php if(isset($restaurants)): ?>
<!-- __BLOCK__ --><?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<tr>
<td> <?php echo e($r->restaurant_name); ?> </td> <td> <?php echo e($r->cuisine_type); ?></td>
<td> <?php echo e($r->address); ?></td> <td> <?php echo e($r->phone); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
<?php else: ?>
<tr>
<td>
nothing to show
</td>
</tr>
<?php endif; ?> <!-- __ENDBLOCK__ -->
</table>
</div>
</div>
<?php /**PATH D:\testing\restaurant_management\resources\views/livewire/search-restaurants.blade.php ENDPATH**/ ?>