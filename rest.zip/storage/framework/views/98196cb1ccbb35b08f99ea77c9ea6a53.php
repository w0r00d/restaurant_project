

<?php $__env->startSection('content'); ?>
    
<div class="myList"> 
    <h4> List of reviews </h4>
    <table> 
        <thead>
<th> Restaurant </th>
<th> Avg rating </th>
        <th> number of reviews </th>
        </thead>
    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
    <td>
    <div class="list-item"> <?php echo e($review->restaurant_name); ?>  </div>
    </td>
    <td>
        <div class="list-item"> <?php echo e(round($review->val,2)); ?> </div>
    </td>
    <td>
        <div class="list-item"> <?php echo e($review->cnt); ?> </div>
    </td>
</tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\testing\restaurant_management\resources\views/all-reviews.blade.php ENDPATH**/ ?>