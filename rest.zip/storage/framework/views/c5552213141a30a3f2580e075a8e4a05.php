
                
                <?php $__env->startSection('content'); ?>
                <div class="myForm" style="margin-left: 500px;">
               
                <form method="post" action="<?php echo e(url('store-form')); ?>">
                    <?php echo csrf_field(); ?>
                    <h3> Add New Restaurant </h3>
                    <span class="myInput">
                
                    <input type="text" id ="restaurant_name" name="restaurant_name" placeholder="name">
                    </span>
                    <span class="myInput">
                 
                    <input type="text" id="cuisine_type" name="cuisine_type" placeholder="cuisine type">
                </span>
                <span class="myInput">
                   
                    <input type="text" id="restaurant_address" name="restaurant_address" placeholder="address">
                </span>
                <span class="myInput">
                 
                    <input type="text" id="restaurant_phone" name="restaurant_phone" placeholder="phone ">
                </span>
                  <button type="submit"> Submit </button>
                 </form>
                </div>
           <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\testing\restaurant_management\resources\views/new-restaurant.blade.php ENDPATH**/ ?>