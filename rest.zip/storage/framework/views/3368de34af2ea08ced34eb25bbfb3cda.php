<div>
    
<center>
    <div class="myForm">
<?php echo e($error); ?>


<!-- __BLOCK__ --><?php if(isset($restaurant_id)): ?>
    <?php echo e($restaurant_id); ?>

    <?php else: ?>
    <?php echo e(5); ?>

<?php endif; ?> <!-- __ENDBLOCK__ -->
        <table>
<tr> <h3> Review Restaurant </h3></tr>
            <tr>

<td>    
    <select wire:model="rid" >
        
        <!-- __BLOCK__ --><?php $__currentLoopData = \App\Models\Restaurant::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($r->id); ?>"><?php echo e($r->restaurant_name); ?>, <?php echo e($r->id); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
    </select>
</td>
            </tr>
<tr>
<td colspan="2">
    <center>
Rate the restaurant 
    </center>
</td>
</tr>
            <tr>

<td>
    <input  type="radio" wire:model="rate" value="1">  
    <label for="1"> 1</label>
    <input type="radio" wire:model="rate" value="2"> 2
    <input type="radio" wire:model="rate" value="3"> 3
    
</td>
            </tr>
            <tr>
<td>
<center>
<button wire:click="rating"> Rate </button>
</center>
</td>
            </tr>
        </table>
    </div>
</center>
</div>
<?php /**PATH D:\testing\restaurant_management\resources\views/livewire/reviewing.blade.php ENDPATH**/ ?>