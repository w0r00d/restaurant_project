
    
<div class="myList"> 
    <h4> List of restaurants </h4>
    <table> 
    <!-- __BLOCK__ --><?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td>
    <div class="list-item"> <?php echo e($r->restaurant_name); ?> </div>
    </td>
    <td>
        <button class="B">  make order </button>
    </td>
</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
    </table>
</div>
</div><?php /**PATH D:\testing\restaurant_management\resources\views/livewire/restaurant-list.blade.php ENDPATH**/ ?>