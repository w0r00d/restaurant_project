
<?php $__env->startSection('content'); ?>
    
<div class="myList" style="width: 500px; margin-left: 30%;"> 
    <h4> My orders  </h4>
    <table> 
        <tr>

<th> Restaurant Name </th>
<th> Order Details </th>
    <th> Order Total</th>
    <th> Order Status</th>
    
        </tr>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td>
    
    <div class="list-item"> <?php echo e($order->restaurant->restaurant_name); ?> </div>
        </td>
  
    <td>
        <div class="list-item"> <?php echo e($order->order_details); ?> </div>
    </td>
    <td>
     
            <div class="list-item"> <?php echo e($order->order_total); ?> </div>
    </td>
    <td>
     
        <div class="list-item"> 
        <?php if($order->order_status): ?>
            pending
        <?php else: ?>
        delivered
        <?php endif; ?>
        </div>
</td>

   
</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\testing\restaurant_management\resources\views/myorders.blade.php ENDPATH**/ ?>