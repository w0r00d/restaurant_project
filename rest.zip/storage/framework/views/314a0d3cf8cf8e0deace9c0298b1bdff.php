

<?php $__env->startSection('content'); ?>
<div class="myForm" style="margin-left: 500px;">

<form method="post" action="<?php echo e(url('store-order')); ?>">
    <?php echo csrf_field(); ?>
    <h3> Make Order </h3>
    <span class="myInput">

        <select name="restaurant_id" >
            <option disabled selected> choose restaurant </option>
            <?php $__currentLoopData = \App\Models\Restaurant::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($r->id); ?>"><?php echo e($r->restaurant_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </span>
    <span class="myInput">
 
    <input type="text" id="details" name="details" placeholder="details">
</span>
<span class="myInput">
   
    <input type="radio" id="type" name="type" value="1" > Indoor
    <input type="radio" id="type" name="type" value="2" > Delivery
</span>

  <button type="submit"> Submit </button>
 </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.myapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\testing\restaurant_management\resources\views/add-order.blade.php ENDPATH**/ ?>