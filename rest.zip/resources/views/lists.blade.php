@extends('layouts.myapp')

@section('content')

    @livewire('restaurant-list')


@endsection

