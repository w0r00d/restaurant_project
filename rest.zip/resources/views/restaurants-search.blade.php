@extends('layouts.myapp')

@section('content')

    @livewire('search-restaurants')


@endsection

