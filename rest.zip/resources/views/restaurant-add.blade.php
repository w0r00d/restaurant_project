@extends('layouts.myapp')

@section('content')

    @livewire('restaurantcomponent')


@endsection

