@extends('layouts.myapp')

@section('content')

    @livewire('reviewing')


@endsection

